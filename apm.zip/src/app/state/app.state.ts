export interface State {
    user: any
}