import { PipeTransform, Pipe } from '@angular/core';
import { busModel } from '../model/bus.model';

@Pipe({
    name: 'busFilter',
    pure: false,
})
export class busFilterPipe implements PipeTransform {
    transform(buses:busModel[], fromCity: string, toCity:string, date: Date):busModel[]  {
        if(buses && buses.length){
            return buses.filter(bus => {
                if(fromCity && bus.fromCity.toLowerCase().indexOf(fromCity.toLowerCase()) === -1){
                    return false;
                }
                if(toCity && bus.toCity.toLowerCase().indexOf(toCity.toLowerCase()) === -1){
                    return false;
                }
                // if(date && bus.date.indexOf(date.toString) === -1){
                //     return false;
                // }
                return true;
            })
        }
        else {
            return buses;
        }
    }

    // transform(buses:busModel[], filter: {[key:string]:any}):busModel[]  {
    //     if(buses && buses.length){
    //         return buses.filter(bus => {
    //             let notmatchingField = Object.keys(filter)
    //                                             .find(key => bus[key] !== filter[key]);
    //             return !notmatchingField
    //         })
    //     }
    // }
}