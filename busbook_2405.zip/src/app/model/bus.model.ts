export class busModel {
    fromCity: string;
    toCity: string;
    date: string
}