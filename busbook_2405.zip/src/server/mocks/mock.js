const mock = {};

mock.auth_mock = {
    auth_data: [
        { email: "admin", password: "admin", role: "admin" },
        { email: "user", password: "user", role: "user" }
    ]
};

mock.buses_mock = {
    availableBuses: [
        {
            '_id': '1',
            'fromCity': 'city 1',
            'toCity': 'city 2',
            'date': '2019-05-27',
            'seats': 10,
        },
        {
            '_id': '1',
            'fromCity': 'city 1',
            'toCity': 'city 3',
            'date': '2019-05-28',
            'seats': 20,
        },
        {
            '_id': '1',
            'fromCity': 'city 2',
            'toCity': 'city 1',
            'date': '2019-05-29',
            'seats': 30,
        },
        {
            '_id': '1',
            'fromCity': 'city 2',
            'toCity': 'city 3',
            'date': '2019-05-30',
            'seats': 40,
        },
        {
            '_id': '1',
            'fromCity': 'city 3',
            'toCity': 'city 1',
            'date': '2019-05-31',
            'seats': 50,
        },
        {
            '_id': '1',
            'fromCity': 'city 3',
            'toCity': 'city 2',
            'date': '2019-06-01',
            'seats': 60,
        },
        {
            '_id': '1',
            'fromCity': 'city 3',
            'toCity': 'city 4',
            'date': '2019-06-02',
            'seats': 70,
        }
    ]
}

module.exports = mock;