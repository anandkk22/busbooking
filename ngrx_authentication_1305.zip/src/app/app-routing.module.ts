import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginInComponent } from './components/login-in/login-in.component';
import { LandingComponent } from './components/landing/landing.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';

const routes: Routes = [
  { path: 'log-in', component: LoginInComponent  },
  { path: 'sign-up', component: SignUpComponent  },  
  { path: '', component: LandingComponent  },
  { path: '**', redirectTo:'/log-in', pathMatch: 'full'}
];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
