import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginNewComponent } from './login-new/login-new.component';
import { BusComponent } from './bus/bus.component';
import {RegisterComponent} from './register/register.component'
import { AuthGuard } from './auth.guard';
import { Availablebuses } from './availableBuses/available-buses.component';

const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginNewComponent },
  { path: 'bus', component: BusComponent, canActivate: [AuthGuard] },
  { path: 'register', component: RegisterComponent },
  { path: 'availablebuses', component: Availablebuses },
  { path: '', redirectTo:'/home', pathMatch: 'full'}
]

@NgModule({
  imports: [    
    RouterModule.forRoot(appRoutes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
