export class busModel {
    fromCity: string;
    toCity: string;
    date: any;
}