import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerUserData = {}
  registerForm: FormGroup;
  validationMessage = {
    'email': {
      'required': 'Email is required',
    },
    'password': {
      'required': 'Password is required'
    }
  };

  formsErrors = {
    'email': '',
    'password': ''
  };

  constructor(private store: Store<any>, private fb: FormBuilder, private _auth: AuthService, private _router: Router) { }

  ngOnInit() {
    this.registerForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.registerForm.valueChanges.subscribe((data) => {
      this.loginValidationErrors(this.registerForm);
    });
  }

  loginValidationErrors(group: FormGroup = this.registerForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const storeControl = group.get(key);
      this.formsErrors[key] = '';

      if (storeControl && !storeControl.valid &&
        (storeControl.touched || storeControl.dirty)) {
        const messages = this.validationMessage[key];
        for (const errorKey in storeControl.errors) {
          if (errorKey) {
            this.formsErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
    })
  }

  registerUser(): void {
    this._auth.registerUser(this.registerUserData)
      .subscribe(
        res => {
          localStorage.setItem('token', res.token)
          this._router.navigate(['/bus'])
        },
        err => console.log(err)
      )
  }

}
