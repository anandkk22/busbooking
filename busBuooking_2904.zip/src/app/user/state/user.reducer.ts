export function reducer(state, action) {
    switch (action.type) {
        case 'LOAD USER':
            return {
                ...state,
                DisplayUser: action.payload
            }
        default:
        return state;
    }
}