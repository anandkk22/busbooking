import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { reducer } from './state/user.reducer';

import { LoginNewComponent } from '../login-new/login-new.component';


const userRoutes: Routes = [
    { path: 'login', component: LoginNewComponent }
  ];

@NgModule({
    imports: [
        RouterModule.forChild(userRoutes),
        StoreModule.forFeature('users', reducer),
        
    ],
    declarations: [
        LoginNewComponent
    ]
})
export class UserModule { }
