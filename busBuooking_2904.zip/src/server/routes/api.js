const express = require('express')
const jwt = require('jsonwebtoken')
const router = express.Router()
const User = require('../models/user')

const mongoose = require('mongoose')
const db = 'mongodb://user1:user12345@ds145486.mlab.com:45486/eventsdb'

mongoose.connect(db, err => {
    if (err) {
        console.error('error' + err)
    } else {
        console.log('Connected to mongodb')
    }
})

// function verifyToken(req, res, next){
//     if(!req.header.authorization){
//         return res.status(401).send('Unauthorized request')
//     }
//     let token = req.header.authorization.split('  ')[1]
//     if(token === 'null'){
//         return res.status(401).send('Unauthorized request')
//     }
//     let payload = jwt.verify(token, 'secretKey')
//     if(!payload){
//         return res.status(401).send('Unauthorized request')
//     }
//     req.userId = payload.subject
//     next()
// }

router.get('/', (req, res) => {
    res.send('From API route')
})

router.post('/register', (req, res) => {
    let userData = req.body
    let user = new User(userData)
    user.save((error, registeredUser) => {
        if (error) {
            console.log(error)
        } else {
            let payload = {subject: registeredUser._id}
            let token = jwt.sign(payload, 'secretKey')
            res.status(200).send({token})
        }
    })
})

router.post('/login', (req, res) => {
    let userData = req.body

    User.findOne({ email: userData.email }, (error, user) => {
        if (error) {
            console.log(error)
        } else {
            if (!user) {
                res.status(401).send('Invalid email')
            } else
                if (user.password !== userData.password) {
                    res.status(401).send('Invalid password')
                } else {
                    let payload = { subject: user._id}
                    let token = jwt.sign(payload, 'secretKey')
                    res.status(200).send({token})
                }
        }
    })
})

router.get('/availablebuses', (req, res) =>{
    let buses = [
        {
            '_id': '1',
            'fromCity': 'city 1',
            'toCity': 'city 2',
            'date': '2019-05-01',
            'seats': 10,
        },
        {
            '_id': '2',
            'fromCity': 'city 1',
            'toCity': 'city 3',
            'date': '2019-05-02',
            'seats': 20,
        },
        {
            '_id': '3',
            'fromCity': 'city 1',
            'toCity': 'city 4',
            'date': '2019-05-03',
            'seats': 30,
        },
        {
            '_id': '4',
            'fromCity': 'city 1',
            'toCity': 'city 5',
            'date': '2019-05-04',
            'seats': 40,
        },
        {
            '_id': '5',
            'fromCity': 'city 2',
            'toCity': 'city 3',
            'date': '2019-05-05',
            'seats': 50,
        },
        {
            '_id': '6',
            'fromCity': 'city 2',
            'toCity': 'city 4',
            'date': '2019-05-06',
            'seats': 60,
        },
        {
            '_id': '7',
            'fromCity': 'city 2',
            'toCity': 'city 5',
            'date': '2019-05-07',
            'seats': 70,
        },
        {
            '_id': '8',
            'fromCity': 'city 3',
            'toCity': 'city 4',
            'date': '2019-05-08',
            'seats': 80,
        },
        {
            '_id': '9',
            'fromCity': 'city 3',
            'toCity': 'city 5',
            'date': '2019-05-09',
            'seats': 90,
        },
        {
            '_id': '10',
            'fromCity': 'city 5',
            'toCity': 'city 2',
            'date': '2019-05-10',
            'seats': 100,
        },
    ]
    res.json(buses)
})


module.exports = router