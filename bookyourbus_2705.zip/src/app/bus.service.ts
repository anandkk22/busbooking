import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { busModel } from './model/bus.model';


@Injectable({
  providedIn: 'root'
})
export class BusService {
  private _busService = 'http://localhost:3000/availabelBuses';

  constructor(private http: HttpClient) { }

  getBusService() {    
    return this.http.get<busModel>(this._busService);    
  }
}
