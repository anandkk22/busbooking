import { Injectable } from "@angular/core";
import { Actions, Effect, ofType } from '@ngrx/effects';
import { AuthService } from '../auth.service';
import { Observable, of } from 'rxjs';
import { mergeMap, map, catchError } from 'rxjs/operators';

import { Action } from '@ngrx/store';
import * as loginActions from './login.actions'

@Injectable()
export class LoginEffects {
    constructor(private actions$: Actions, private authServices: AuthService) { }

    @Effect()
    login$: Observable<Action> = this.actions$.pipe(
        ofType(loginActions.AuthActionTypes.LOGIN),
        mergeMap(action => this.authServices.logIn('a@a.com','a').pipe(
            map(users => (new loginActions.LogIn(users))),
            catchError(err => of(new loginActions.LogInFailure(err)))
        ))
    )
}