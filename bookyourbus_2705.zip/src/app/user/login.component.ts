import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { User } from './user';
import { Observable } from 'rxjs';

import * as UserLogin from '../user/state/user.reducer'

@Component({
  selector: 'app-login-new',
  templateUrl: './login.component.html',
  
})
export class LoginComponent implements OnInit {
  loginUserData = {};
  loginForm: FormGroup;
  validationMessage = {
    'email': {
      'required': 'Email is required',
    },
    'password': {
      'required': 'Password is required'
    }
  };

  formsErrors = {
    'email': '',
    'password': ''
  };


  loginUserDate = {};

  users$: Observable<User[]>;


  constructor(private store: Store<UserLogin.UserState>, private fb: FormBuilder, 
    private _auth: AuthService, private _router: Router,
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.loginForm.valueChanges.subscribe((data) => {
      this.loginValidationErrors(this.loginForm);
    });
  }

  loginValidationErrors(group: FormGroup = this.loginForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const storeControl = group.get(key);
      this.formsErrors[key] = '';

      if (storeControl && !storeControl.valid &&
        (storeControl.touched || storeControl.dirty)) {
        const messages = this.validationMessage[key];
        for (const errorKey in storeControl.errors) {
          if (errorKey) {
            this.formsErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
    });
  }
  
  loginUser(){    
    this.users$ = this.store.pipe(select(UserLogin.getCurrentUser)) as Observable<User[]>

    // this._auth.logiUser(this.loginUserData)
    //     .subscribe(
    //       res => {
    //         localStorage.setItem('token', res.token);
    //         this._router.navigate(['/bus']);
    //       },
    //       err => console.log(err)
    //     );
  }

}
