import { Component, OnInit } from '@angular/core';
import { BusService } from '../bus.service';
import { busModel } from '../model/bus.model';

@Component({
    selector: 'availablebuses',
  templateUrl: './available-buses.component.html',
  
})
export class Availablebuses implements OnInit {
    availableBuses: busModel;
    constructor(private busservices: BusService) { }

    ngOnInit() {
        // this.busservices.getBusService()
        // .subscribe(
        //     res => this.availableBuses= res,
        //     err => console.log(err)
        // )
    }

}