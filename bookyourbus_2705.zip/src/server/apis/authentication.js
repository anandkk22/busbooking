const mock = require('../mocks/mock');

exports.authenticateUser = function(request, response) {
    try {        
        const reqBody = request.body;
        var respData = {};
        const authMock = mock.auth_mock.auth_data;
        
        authMock.forEach(elm => {

            if (elm.email == reqBody.email && elm.password == reqBody.password) {
                respData = { data: { email: elm.email, role: elm.role }, message: "Login Successfull" };
            }
        });
       
        if (respData.data) {
            response.status(200).send(respData);
        } else {
            respData = { message: "Invalid Credentials" }
            response.status(401).send(respData);
        }
    } catch (err) {
        console.log(err);
        respData = { message: 'Something Went Wrong.' }
        response.status(500).send(respData);
    }
}