// import { Injectable } from '@angular/core';
// import { user } from './user';
// import { observable } from 'rxjs';
// import 'rxjs/add/observable/of';

// export const UserList = new user();
// UserList.username = 'username';
// UserList.password = 'password';


// @Injectable()
// export class UserService {
//     private _authenticated = false;


//     public authenticate(username: string, password: string) {
//         if (username === UserList.username && password === UserList.password) {
//             this._authenticated = true;

//             return observable.of(UserList)
//         }
//         return observable.throw(new Error('Invalid username and password'))
//     }
// }