import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-new',
  templateUrl: './login-new.component.html',
  styleUrls: ['./login-new.component.css']
})
export class LoginNewComponent implements OnInit {
  loginUserData = {}
  loginForm: FormGroup;
  validationMessage = {
    'email': {
      'required': 'Email is required',    
    },
    'password': {
      'required': 'Password is required'
    }
  };

  formsErrors = {
    'email': '',
    'password': ''
  };


  loginUserDate = {}

  constructor(private store: Store<any>, private fb: FormBuilder, private _auth:AuthService, private _router: Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.loginForm.valueChanges.subscribe((data) => {
      this.loginValidationErrors(this.loginForm);
    });
  }

  loginValidationErrors(group: FormGroup = this.loginForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const storeControl = group.get(key);      
      this.formsErrors[key] = '';

      if (storeControl && !storeControl.valid &&
        (storeControl.touched || storeControl.dirty)) {
        const messages = this.validationMessage[key];
        for (const errorKey in storeControl.errors) {
          if (errorKey) {
            this.formsErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
    })
  }
  loginUser() {
    this._auth.logiUser(this.loginUserData)
        .subscribe(
          res => {
            localStorage.setItem('token', res.token)
            this._router.navigate(['/bus'])
          },
          err => console.log(err)
        )
  }

}
