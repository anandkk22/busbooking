import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {City} from '../model/busbooking.model';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { busModel } from '../model/bus.model';

@Component({
  selector: 'app-bus',
  templateUrl: './bus.component.html',
  styleUrls: ['./bus.component.css']
})
export class BusComponent implements OnInit {
  busbooking: busModel = {
    fromCity: null,
    toCity: null,
    date: null
  };

  datePickerConfig: Partial<BsDatepickerConfig>;
  cities: City[] = [
    {id:1, name: 'city 1'},
    {id:2, name: 'city 2'},
    {id:3, name: 'city 3'},
    {id:4, name: 'city 4'},
    {id:5, name: 'city 5'}
  ];

  busbookingForm: FormGroup;
  validationMessage = {
    'fromCity': {
      'required': 'From is required',
    },
    'toCity': {
      'required': 'To is required',
    },
    'date': {
      'required': 'Date is required',
    }
  };

  formsErrors = {
    'fromCity': '',
    'toCity': '',
    'date': ''
  }; 
  constructor(private fb: FormBuilder) {
    
    this.datePickerConfig = Object.assign({}, {
      containerClass: 'theme-dark-blue', 
      showWeekNumbers: false,
      minDate: new Date()
    });
   }

  ngOnInit() {
    this.busbookingForm = this.fb.group({
      fromCity: ['', Validators.required],
      toCity: ['', Validators.required],
      date: ['', Validators.required]
    });

    this.busbookingForm.valueChanges.subscribe((data) => {
      this.busbookingValidationErrors(this.busbookingForm);
    });
  }

  busbookingValidationErrors(group: FormGroup = this.busbookingForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const storeControl = group.get(key);
      this.formsErrors[key] = '';

      if (storeControl && !storeControl.valid &&
        (storeControl.touched || storeControl.dirty)) {
        const messages = this.validationMessage[key];
        for (const errorKey in storeControl.errors) {
          if (errorKey) {
            this.formsErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
    })
  }

  searchBus(): void {
    console.log(this.busbookingForm)
  }

}
