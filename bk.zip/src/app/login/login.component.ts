import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  validationMessage = {
    'userName': {
      'required': 'User name is required',
      'minlength': 'User name must be greater than 3 characters',
      'maxlength': 'User name must be less than 20 characters',
    },
    'password': {
      'required': 'Password is required'
    }
  };

  formsErrors = {
    'userName': '',
    'password': ''
  };

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      userName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      password: ['', Validators.required]
    });

    this.loginForm.valueChanges.subscribe((data) => {
      this.loginValidationErrors(this.loginForm);
    });
  }

  loginValidationErrors(group: FormGroup = this.loginForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const storeControl = group.get(key);
      // if(storeControl instanceof FormGroup) {
      //   this.logValidationErrors(storeControl);
      // } else {
      //   storeControl
      // }
      this.formsErrors[key] = '';

      if (storeControl && !storeControl.valid &&
        (storeControl.touched || storeControl.dirty)) {
        const messages = this.validationMessage[key];
        for (const errorKey in storeControl.errors) {
          if (errorKey) {
            this.formsErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
    })
  }

  onSubmit(): void {
    this.loginValidationErrors(this.loginForm);
    console.log(this.formsErrors);
  }

}
